# NovaInsert Library Guide

NovaInsert arrives with reusable Library Insert Sets, or LIS files. They are not merely sample data. Some save typing; others provide disciplined ways to reason, manage AI agents, test changes and verify important work.

This guide explains what each supplied set is for, when it helps and what to check before using it.

## How a Library set becomes useful

A LIS contains ordered Inserts but no destination.

To use a set repeatedly:

1. Open Project management.
2. Open **LIS**.
3. Attach the set.
4. Choose a Linked Window or NIT destination.
5. Review Fields, **Add Enter**, CD and Return to NI.
6. Save.

To borrow one line without attaching the set:

1. Open **... → Library**.
2. Find the line. Click a row title to open or close that branch; this works at top level and lower levels.
3. Select its **toCB** button.
4. Paste it into an Insert editor or wherever you need it.

Library **toCB** copies the exact stored text. It does not fill Project Fields. To combine lines from different sets, copy and paste each chosen line into your Project Inserts one at a time.

## Read before executing commands

The Library includes ordinary prose, AI instructions, Windows commands and development commands.

- Prose and AI instructions are sent as text.
- Commands may inspect, build or change the current environment.
- `[Field]` values must be reviewed.
- **Add Enter** determines whether a command is actually run.
- A KBD Insert performs keys immediately in its destination.

Test unfamiliar entries in a harmless destination first.

## The most important supplied groups

If you use AI, start with these:

1. **AI → 4E → LLM** — a complete evidence-based thinking loop.
2. **AI → 4E → Agentic** — adds authority, execution and accountability.
3. **AI → Agent → Manager** — turns an objective into bounded responsibilities.
4. **AI → Agent → Boundaries** — prevents vague or excessive authority.
5. **AI → Agent → Escalate** — tells an agent when to stop and ask.
6. **AI → Agent → Verify** — checks outcomes separately from claims of completion.
7. **AI → Red Team** — challenges assumptions and failure paths.
8. **AI → Test → Agent Evaluation** — tests agent behavior rather than exact wording.
9. **AI → Code Review** — performs focused review against contracts and evidence.
10. **AI → Test → Production** — turns real failures into permanent learning.

These sets are useful beyond coding. The same ideas apply when AI helps research a purchase, plan travel, organize family work, prepare documents or perform actions through connected tools.

## AI → 4E

### AI → 4E → LLM

Use this when a question is important enough that the first plausible answer is not sufficient.

The sequence is:

**Explore → Evidence → Evaluate → Engineer → Verify → Loop**

- **Explore** generates possibilities without pretending they are facts.
- **Evidence** separates what is known from assumptions.
- **Evaluate** compares real alternatives and risks.
- **Engineer** creates a bounded plan with acceptance criteria.
- **Verify** checks the result independently.
- **Loop** treats results and surprises as new evidence.

Good uses include comparing products, planning a major task, researching an unfamiliar subject and preparing a decision.

### AI → 4E → Agentic

Use this when AI may do more than advise—especially when it can use tools or change something.

The set adds:

- explicit execution boundaries;
- authorized actions only;
- independent verification;
- new evidence from actual outcomes;
- a named human accountable for consequential results.

Use it before granting an agent access to files, messages, purchases, schedules, production systems or other meaningful actions.

## AI → LLM

These sets let you use one stage of the thinking loop without sending the entire framework.

### AI → LLM → Explore

Use when you need possibilities, questions, alternative explanations or useful areas to investigate. It deliberately avoids choosing a winner too early.

### AI → LLM → Evidence

Use when facts and sources matter. It asks the AI to distinguish Fact, Observation, Inference, Assumption and Opinion; identify missing evidence; and look for contradictions.

### AI → LLM → Evaluate

Use after viable choices and evidence exist. It compares costs, benefits, risks, dependencies, reversibility and the consequences of doing nothing.

### AI → LLM → Engineer

Use after choosing a direction. It turns that direction into a bounded plan with responsibilities, inputs, outputs, dependencies, approval points, stop conditions and measurable acceptance criteria.

### AI → LLM → Verify

Use after work is reported complete. It compares expected and actual results, challenges unsupported conclusions and looks for unintended effects.

## AI → Agent

An AI assistant gives information. An AI agent has responsibility and may use tools to pursue an outcome. These sets help you remain the accountable manager.

### AI → Agent → Autonomy

Use to choose how much freedom is appropriate:

- AI assists while you act.
- AI recommends while you decide and act.
- AI prepares an action for your approval.
- AI acts inside defined boundaries and escalates exceptions.
- AI plans and executes a substantial workflow under oversight.

Choose autonomy from consequence, risk, reversibility, evidence and verification—not from novelty.

### AI → Agent → Boundaries

Use before execution. Define allowed actions, forbidden actions, accessible data, spending or communication limits, approval gates and least privilege.

### AI → Agent → Delegate

Use when handing one responsibility to an agent. It asks for the objective, necessary context, inputs, outputs, definition of done, dependencies and reporting rules.

### AI → Agent → Escalate

Use to define when the agent must stop, request approval or report uncertainty. This is particularly important when information conflicts, tools fail, permissions are missing or an action is irreversible.

### AI → Agent → Execute

Use after the plan and boundaries are approved. It emphasizes authorized tools, material action records, exception reporting and actual outcomes.

### AI → Agent → Verify

Use after execution. It asks for independent evidence, boundary compliance, unintended effects and actual outcome—not merely task completion.

### AI → Agent → Manage

Use for ongoing human oversight. It covers ownership, decomposition, assignments, boundaries, evidence, challenge, monitoring, verification and learning.

### AI → Agent → Manager

Use as the compact management sequence:

**Objective → Decompose → Assign → Context → Bound → Approve → Monitor → Escalate → Verify → Learn**

This is one of the most important sets when multiple people, agents or systems share a goal.

### AI → Agent → Development Testing

Use when agents help change software. It connects the exact change to impact, focused tests, contracts, integration, agent evaluations, adversarial tests, regression, release and production evidence.

Non-developers can ignore this set unless they are supervising software work.

## AI review and challenge

### AI → Code Review

Use when you want concrete source review rather than general comments. Its Inserts request:

- correctness and maintainability findings by severity;
- the smallest supported defect fix;
- tracing through UI, state, service, persistence and output;
- regression review;
- useful deduplication only;
- unsupported API, race and destructive-path checks;
- focused tests;
- comparison with the approved contract.

Attach it to the AI conversation used for the current project, then select the review question that matches the need.

### AI → Red Team

Use before a consequential decision or release. It challenges assumptions, searches for contrary evidence, identifies missing evidence, finds failure modes, questions excessive authority and asks what would reverse the decision.

Red Team is not automatic rejection. Its purpose is to expose weaknesses before reality does.

## AI → Test

### AI → Test → Change

Use for one new or fixed behavior. Identify exactly what changed, reproduce defects, test the happy path and important boundaries, then run the smallest suite that proves the change.

### AI → Test → Impact

Use when you need to know what else may be affected. It asks for dependencies, callers, interfaces, shared services and broader testing when impact is uncertain.

### AI → Test → Contract

Use for promises between components or to users. It protects required inputs, outputs, interface assumptions, errors and externally visible behavior.

### AI → Test → Adversarial

Use to test missing, contradictory, malformed or misleading input; failing tools; denied permission; prohibited actions; and safe stopping or escalation.

### AI → Test → Regression

Use to preserve earlier failures as permanent tests and decide when targeted, broader and full regression suites should run.

### AI → Test → Agent Evaluation

Use to evaluate agent behavior across representative scenarios. Define permitted and forbidden actions, expected properties, tool use, evidence, escalation and outcome quality. Score behavior, not identical wording.

### AI → Test → Release

Use before releasing software or another repeatable workflow. It covers focused, contract, integration, end-to-end, agent evaluation, regression, target-environment smoke and configuration checks.

### AI → Test → Production

Use after release. Compare actual outcomes with expectations, capture escaped defects, reproduce significant failures and turn them into regression tests or agent evaluation cases.

## Everyday communication

### Everyday Replies

Short professional replies for acknowledging, confirming, scheduling, requesting missing details, completing work or declining attendance.

Customize tone and names before attaching it to an email or messaging Window.

### Issue Templates

Structured templates for:

- Issue / Expected / Actual / Steps / Evidence;
- status reporting;
- decisions and reasons;
- test results;
- handoffs.

These improve communication because they prompt you for the facts another person needs.

## Windows

### Win → Fields

Examples of normal Project Fields, optional Fields and automatic WIN Fields. Use this set to learn syntax or copy an example into your own Insert.

It includes `[WIN:CB]`, which reads the current text Clipboard. Treat Clipboard contents as data and review where they will be sent.

### Win → Keyboard

Examples of exact KBD Inserts such as Copy, Paste, Select All, Undo, hard refresh, F5, Tab and Escape.

A KBD entry performs keys when executed. Make sure the correct application and control are active.

### Win → PowerShell

Common PowerShell inspection and navigation commands, including location, files, commands, help, processes, services and history.

Entries containing `[ProjectRoot]` or `[CommandName]` require Project Field values. Review **Add Enter**.

### Win → Diagnostics

Commands for computer, operating system, disks, network adapters, IP configuration, connectivity, DNS and recent Windows events.

Some output can contain machine names, addresses or configuration details. Review it before sharing externally.

### Win → WSL Ubuntu

Read-oriented commands for WSL status, distributions, Ubuntu identity, storage, memory, networking and current files.

The supplied set does not update, shut down or install packages.

## Raspberry Pi

### Pi → Backup Node

Commands for setting up and checking a Raspberry Pi backup node with fixed-IP networking, an external shared drive, Samba and Syncthing.

Fields include `[FixedIP]`, `[GatewayIP]`, `[SharePath]`, `[DriveLabel]` and `[UserName]`. Review every command before using **Add Enter**, especially commands that edit `fstab`, edit Samba configuration, restart services or mount drives.

## Development

These sets are conveniences for people who already understand the tools. They do not decide which command is appropriate.

### Dev → Dotnet

.NET information, restore, build, test, clean and outdated-package checks.

### Dev → Git

Status, diff, log, branch, add, commit, pull and push commands. `[CommitMessage]` is required for commit. Review changes before `git add -A`, commit, pull or push.

### Dev → Node Vite

Node/npm versions, dependency installation, development server, build, test, lint and outdated-package checks.

### Dev → React Native

Environment doctor, dependencies, development server, Android build/run, tests, lint and Gradle build/clean.

### Dev → Android ADB

Connected-device facts, Android version, manufacturer/model, third-party packages, bounded logs, APK installation and Gradle tests.

`[ApkPath]` must identify the intended APK. Confirm the connected device before install or device tests.

## Media

### Media → FFmpeg

Commands for version checks, media inspection, stream copying, MP3 extraction, aspect-preserving resize, trimming, frame extraction and concatenation.

Fields include `[InputFile]`, `[OutputFile]`, `[OutputFolder]`, `[StartTime]`, `[EndTime]` and `[FileList]`. Test with copies of valuable media.

## Customize without losing your work

Open **... → Library → Open Folder** to reach:

```text
%LOCALAPPDATA%\NovaInsert\Library
```

Use filenames such as:

```text
Category - Subcategory - Set Name.lis.json
```

Then return to NovaInsert and select **Scan**.

The Starter Library copies a file only when its filename is absent. Your edited file is not overwritten during ordinary startup.

For major customization, copy a supplied set to a new descriptive filename. This keeps your version clearly separate from the original purpose.
