# NovaInsert Engineering Guide

This guide describes how NovaInsert 1.0 is designed, coded, tested and packaged. The other shipped guides describe how to use the product.

## 1. Platform and Boundaries

- .NET 8 WPF application for Windows.
- JSON stores for application state.
- DPAPI-backed encryption for Hideout.
- Win32 for exact Window activation, focus, input and global hotkey behavior.
- UI Automation plus a native C++ helper for exact Windows Terminal tabs.
- `wt.exe` only for explicitly creating missing NIT tabs.
- xUnit for automated service and state tests.

There are no browser extensions, terminal profile-database edits, undocumented browser internals or silent destination fallbacks.

## 2. Source Responsibilities

| Area | Responsibility |
| --- | --- |
| `Shell\` | Composition, lifecycle, status, theme, single instance, toNI and global hotkey |
| `Projects\` | Projects, TODO, LIS attachment and Project routing |
| `ActorManagement\` | Linked Window creation and editing |
| `TextActions\` | Inserts, Field preparation, keyboard parsing and ordinary execution |
| `ProjectFields\` | Project and WIN Field discovery, storage and resolution |
| `Targeting\` | Exact Window capture, resolution, identification, activation and saved click point |
| `Library\` | LIS discovery, editing and file management |
| `NIT\` | Managed Terminal plan, tab state and protocol client |
| `TerminalNative\` | Exact Terminal discovery, tab selection, verification and input |
| `Hideout\` | Encrypted values, temporary authorization and direct keyboard delivery |
| `Guides\` | Guide discovery, shared Starter/Final composition and Markdown display |
| `Shared\` | Reused controls, flyouts, dialogs and presentation primitives |

`Shell\QeApplicationComposition.cs` constructs the dependency graph. Feature code receives its dependencies rather than locating global state.

## 3. Core State

### Project

Owns identity, name, icon, order, TODO and LIS attachments. Home is a fixed Project identity using the same operational model.

### Linked Window

Belongs to one Project and owns its saved Inserts. Its binding records process identity, Window identity and normalized click coordinates.

### Insert

Owns text, note, order, enabled state and Add Enter. Its text may include Project Fields, WIN Fields, or exactly one complete KBD expression.

### LIS

One external `.lis.json` file containing ordered Inserts. Routing is attachment state stored by the Project, not metadata in the LIS file.

### LIS attachment

Selects either one Project-owned Linked Window or NIT. NIT adds exact tab selection, optional CD and Return Focus.

## 4. Startup and Lifetime

`App.xaml.cs` enforces one NovaInsert instance before creating `MainWindow`. The named mutex is released automatically if the process exits or crashes.

Startup loads theme, target bindings, Projects, Linked Windows, actions, fields, LIS catalog and Window position. The NIT helper is created on demand and disposed when the main Window closes.

`toNI` exists only in memory and starts empty each run. Hideout target binding is also runtime-only. Project state, LIS attachments, target bindings, theme, Insert defaults and hotkey settings persist.

## 5. Field Pipeline

`ProjectFieldDiscoveryService` recognizes bracketed names. `WIN:` and `KBD:` prefixes are reserved and excluded from editable Project Field discovery.

Project Fields are resolved by Project identity. `[Name]` is required; `[Name?]` is optional. A missing required value stops preparation. A missing optional value becomes empty text.

`WindowsInsertFieldService` resolves:

```text
WIN:USERNAME       WIN:COMPUTERNAME
WIN:USERPROFILE    WIN:DESKTOP
WIN:DOCUMENTS      WIN:DOWNLOADS
WIN:TEMP            WIN:DATE
WIN:TIME            WIN:DATETIME
WIN:OS              WIN:OSVERSION
WIN:CB
```

The Clipboard is read only when `[WIN:CB]` is present. Display text omits the live Clipboard value while execution receives it. Unsupported WIN Fields produce a specific error.

`InsertTransferService` is the shared preparation boundary for execution, toCB and toNI. Ordinary prepared text updates `toNI` on execution. KBD does not.

## 6. KBD Pipeline

`KeyboardCommandParser` accepts only a whole Insert of the form `[KBD:...]`.

- Modifiers: CTRL, SHIFT, ALT and WIN.
- Final key: letter, digit, F1–F24 or a supported named key.
- Modifier order is normalized before delivery.
- Multiple final keys, missing final key, mixed text, or unknown names are rejected.

Ordinary Linked Window KBD activates and re-resolves the exact Window without clicking. `WindowsTextInputService.SendKeyChord` sends ordered key-down input followed by reverse key-up input.

NIT KBD uses one native `KEY` transaction: select exact tab, focus, verify, send and optionally return focus.

## 7. Ordinary Linked Window Execution

One click follows this sequence:

1. Cancel destination identification and close navigation flyouts.
2. Acquire the shared Insert execution lease.
3. Set status to Executing.
4. Resolve Project and WIN Fields and classify KBD versus text.
5. Resolve the exact live Window from the saved binding.
6. Restore and foreground the Window.
7. For text, calculate the current scaled click point and click it.
8. Recheck exact foreground identity.
9. Send KBD, or write the Clipboard and send paste.
10. Recheck focus after paste; optionally send Enter.
11. Restore the original cursor position.
12. Report success or the exact failure.

The execution lease rejects overlapping Inserts instead of queuing them.

## 8. Identification Flashing

Identification is not activation.

`MainWindow.ActorFlyoutEvents.cs` requires a continuous two-second hover before identifying a destination. Moving to another item, leaving the list, closing flyouts or selecting an Insert cancels the pending operation.

`WindowsTargetWindowFlasher` starts flashing without blocking, waits asynchronously for two seconds, then sends `FLASHW_STOP`. Starting another identification cancels and stops the previous one.

The native NIT flash also returns immediately and uses a timed background stop. No identification path brings a Window forward.

## 9. NIT Execution

NIT exists because one Windows Terminal process and one top-level Window can contain multiple tabs. PID and HWND alone cannot identify a tab.

`NitExecutionPlanService` resolves Insert and CD text. `NitTabService` checks exact tab count and supports Refresh, Open and Focus. `NitProtocolClient` owns a persistent helper process and refuses overlapping native operations immediately.

The native transaction:

1. Discover the exact tab name.
2. Reject missing or duplicate names.
3. Select and focus the exact tab.
4. Verify the globally focused UI Automation element.
5. Optionally send resolved CD and Enter.
6. Send text and optional Enter, or send a KBD chord.
7. Verify during the transaction.
8. Optionally restore the previous foreground Window.

Opening creates only the exact configured destination. Saving or detaching never creates, focuses or closes Terminal tabs.

## 10. toNI Global Hotkey

`NiClipboardService` holds session-only resolved text. `NiHotkeyController` registers one configured Ctrl+Alt combination with `MOD_NOREPEAT`.

On activation, `CurrentFieldPasteService`:

1. Captures foreground Window and focused control.
2. Captures all available Clipboard formats.
3. Asynchronously waits until Ctrl, Alt and the trigger key are released.
4. Confirms the same Window and control remain focused.
5. Writes `toNI` text to the Clipboard.
6. Confirms focus again and sends Ctrl+V.
7. Waits asynchronously for paste completion.
8. Restores the previous Clipboard snapshot in `finally`.

The destination is deliberately independent of registered Projects and Linked Windows.

## 11. Hideout

Hideout stores encrypted records using authenticated encryption protected through Windows DPAPI. Authorization and destination binding expire independently.

Hideout resolves an explicitly linked runtime Window, selects the target field, verifies focus and types Unicode characters directly. It does not use the Clipboard and never adds Enter.

## 12. Status and Failure Rules

`ExecutionStatusViewModel` exposes Ready, Executing, Success and Failure. Completed status returns to Ready after ten seconds. Selecting the status clears it immediately.

The status area flashes only for Failure. No mascot animation or status-driven synchronous render is used.

Failures are explicit: missing Field, unavailable Window, relink required, foreground change, Clipboard failure, busy execution, missing NIT tab, duplicate NIT tab, failed verification or protocol error.

## 13. Settings

- Add Enter default applies only to newly created Inserts.
- Hotkey enabled state and choice persist and apply immediately.
- Hotkey Test temporarily checks registration availability and restores the enabled state.
- Dark and Light themes update shared dynamic resources.

An unavailable hotkey reports failure rather than silently choosing another combination.

## 14. Testing

Automated tests cover stores, initialization, Project ownership, LIS isolation, Field discovery and resolution, KBD parsing, execution coordination, transfer behavior, NIT naming/planning/tab state, Hideout encryption and guide discovery.

Manual Windows checks remain required for:

- exact Window activation and click targeting;
- Clipboard restoration and hotkey delivery;
- taskbar/caption flashing and cancellation;
- Windows Terminal UI Automation;
- WPF theme, scaling, flyout and dialog behavior.

Build and test:

```powershell
dotnet build
dotnet test
```

## 15. Deliberately Absent

- No destination guessing or fallback.
- No unattended command queue.
- No terminal tab cleanup on save, detach or exit.
- No mixed text-and-KBD macro language.
- No persistence of `toNI`.
- No source-code or workflow rights implied by the freeware license.
