# README — Start Here

NovaInsert (NI) keeps text, commands and keyboard actions ready, then sends them to the exact place you choose. Watch our YouTube channels for GeezerCoder and JasoosLabs for more detailed videos of many features and hints.

![NovaInsert main window](../Images/01-Main Screen at Startup.png)

You can use it for ordinary writing, repeated replies, Windows work, development commands, AI prompts and agentic-AI workflows. You decide what is sent and when. Don't worry too much as we have given a huge set of starters in Library and a methodology (we call it 5E) to make this an easy repeatable task for you.

## The five things to know

- A **Project** groups work that belongs together.
- A **Linked Window** is an exact ordinary Windows destination.
- An **Insert** is saved text, a command or a keyboard action.
- A **Library Insert Set (LIS)** is a reusable group of Inserts.
- **NIT** is an exact Windows Terminal tab used by a LIS and auto created by NI. Regular terminal and PS Shell are just regular Windows you can also use.

NovaInsert does not guess where you meant to send something. If the saved destination cannot be confirmed, it stops and tells you.

## Your first Insert

Use Notepad for a harmless first test.

Before starting, open **... → Settings → GUI Effects** and turn on **Enable sounds** and **Enable Nova dragon flight**. The dragon flight is useful in the first tutorial because it shows where NovaInsert is flying to before it inserts text.

### 1. Open Notepad

Open Notepad and leave the document empty.

![Empty Notepad window](../Images/02-Notepad.png)

### 2. Create a Project

1. Select **+** on the NovaInsert bar.
2. Name the Project `NI Practice`.
3. Choose an icon.
4. Leave Project management open.

![Empty Notepad window](../Images/03-Adding New Project.png)


### 3. Link Notepad

1. Select **+ Add Linked Window**.
2. When prompted, select the exact place inside the Notepad document where text should go. ```Repeat, when you click on an insert via hover menu, NI will attempt to go to this exact location in this Window and then insert the text. At any time you may move around or resize target window as needed, even to a different monitor```
3. Name the destination `Notepad`.
4. Save the Project.

![Empty Notepad window](../Images/04-Linked Window.png)

NovaInsert remembers that Window and the selected point. If you close the Notepad app the point is no longer suitable, restart Notepad and relink it.

### 4. Create the Insert

**1.** Move the pointer to the Notepad Linked Window and select **Manage**.

**2.** Add a new Insert containing:

```text
Thanks — I’ll review this and get back to you.
```

**3.** Review **Add Enter**. When enabled, choosing this Insert from the hover menu also sends Enter after the text.

![Add an Insert](../Images/04A-Linking A Window.png)

**4.** Save the Insert list.

![Manage the Insert list](../Images/05-Manage Insert List.png)

**5.** Save the Project to return to the main screen.

![Main screen with the Practice Project](../Images/06-Main with Practice Project.png)

### 5. Send it

1. Hover over **NI Practice**.
2. Hover over **Notepad**.  Hold there for 3 seconds (not needed to use NI as we are just showing off the flashing NotePad icon in Windows status bar to tell you which one NI is about to act on.)

![Empty Notepad window](../Images/07-Insert Hover.png)

**3.** Click on the saved Insert once.

NovaInsert brings the exact Notepad Window forward, selects the saved point and sends the text.


![Empty Notepad window](../Images/08-Insert Competion Status.png)

## Read the status before clicking again

- `…` means NovaInsert is working.
- `✓` means the action succeeded.
- `!` means the action stopped.

Hover over the status area to read the full message. Select it to clear the message.

If an Insert does not run, read the status first. Repeated clicks do not correct a missing Window, Field, Clipboard value or Terminal tab.

and in the Notepad you will see

![Empty Notepad window](../Images/09-NotePad with Inserted text.png)

## Three ways to use saved text

### Send to a Linked Window

Select the Insert from its Project and Linked Window. NovaInsert activates the saved destination and sends it.

### Copy with toCB

Select **toCB** to copy the prepared text to the Windows Clipboard. Paste it yourself with normal `Ctrl+V` wherever you choose.

### Keep it in toNI

Select **toNI**, place the cursor in any editable field and press your configured NI hotkey. The destination does not need to be linked to NovaInsert.

`toNI` lasts only for the current NovaInsert session. It is empty after restart.

## Make an Insert reusable with a Field

Change the test Insert to:

```text
Hello [Name], your request is ready.
```

NovaInsert shows **Name** in the Project Fields. Enter its value and save.

- `[Name]` is required. A blank value stops the action.
- `[Name?]` is optional. A blank value becomes empty text.

## Use the supplied Library

NovaInsert includes ready-made sets for:

- everyday replies and issue reporting;
- Windows, PowerShell and diagnostics;
- Raspberry Pi backup-node and shared-drive admin commands;
- development tools;
- media commands;
- AI thinking, evidence and evaluation;
- agent boundaries, delegation and verification;
- testing, review and production checks.

And yes you can add your own libraries and guides to NI, it will pick them up upon app restart for guides and via scan button for libraries.  See Technical Reference.

Open **... → Library** to examine them. Click a Library row title to open or close that branch, even at lower levels. Attach useful sets from Project management.

Read **NovaInsert Library Guide** before using commands you do not recognize. Some supplied sets are much more valuable than simple command shortcuts: they provide reusable ways to manage evidence, AI agents, testing and consequential decisions.

## Choose the next guide

- **NovaInsert User Guide** — complete task-based use of the application.
- **NovaInsert Library Guide** — every supplied Library group and when to use it.
- **Using AI and Agentic AI With NovaInsert** — practical AI work with human control.
- **NovaInsert Engineering Guide** — how NovaInsert itself was designed and coded.

## Basic safety

- Test unfamiliar commands in a harmless destination.
- Check **Add Enter** before sending a command.
- Do not change focus while NovaInsert is sending.
- Use keyboard actions only when you understand their effect.
- Keep passwords and other secrets in Hideout, not ordinary Inserts or Fields.
