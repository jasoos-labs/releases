# Using AI and Agentic AI With NovaInsert

You do not need to be a developer to use AI well. You need a clear outcome, useful context, sensible boundaries and evidence that the result is sound.

NovaInsert helps you keep those instructions ready and reuse them consistently. It does not make decisions for you, grant authority to an AI or verify the truth of an AI response.

## AI assistant versus AI agent

An **AI assistant** usually answers, explains, drafts, compares or recommends. You remain the person performing actions.

An **AI agent** receives responsibility for pursuing an outcome. It may plan several steps, use tools, read or change data, coordinate work, or act within permissions you grant.

The important difference is not whether the AI sounds intelligent. It is whether it can act.

The more an AI can affect, the more clearly you should define:

- its objective;
- what it may see;
- what it may do;
- what it must never do;
- what requires your approval;
- when it must stop;
- how you will verify the result.

## What NovaInsert contributes

NovaInsert can hold:

- your reusable AI instructions;
- Project-specific facts as Fields;
- a TODO for the current goal;
- separate Library sets for thinking, managing, testing and verification;
- exact handoff and reporting templates.

You can attach these sets to the Window where you use AI, or use `toCB`/`toNI` to paste them wherever the current conversation lives.

NovaInsert does not connect to an AI service by itself. It prepares and sends the text you choose.

## Begin with an outcome, not an AI feature

Weak request:

```text
Help me with this.
```

Stronger request:

```text
Goal: Compare three practical ways to organize our family photographs.
Constraints: Windows and Android, simple for nontechnical users, no monthly fee.
Output: A short comparison, recommendation, risks and first safe trial.
Do not purchase, subscribe or delete anything.
```

Put stable values such as a folder, budget or preferred format in Project Fields. Keep the reusable structure in a Library set.

## Use the 5E loop

For a new or uncertain question, use:

**Explore → Evidence → Evaluate → Engineer → Execute**

### Explore

Ask what may be possible before selecting an answer.

Useful Insert:

```text
Generate plausible possibilities without choosing a winner. Identify important questions and what we do not know.
```

### Evidence

Ask what is actually supported.

```text
Separate Fact, Observation, Inference, Assumption, and Opinion. Identify sources, contradictions, and missing evidence.
```

For facts that may have changed, require current sources. For personal files, provide the exact material rather than asking the AI to remember it.

### Evaluate

Compare serious options against the evidence.

```text
Compare costs, benefits, risks, dependencies, reversibility, and the consequences of doing nothing.
```

### Engineer

Turn the chosen direction into a bounded plan.

```text
Define the objective, scope, steps, inputs, outputs, approval points, stop conditions, and measurable definition of done.
```

### Execute

Perform only the approved work. If AI can use tools, execution authority must be explicit.

```text
Execute only the approved bounded plan. Stop and ask before exceeding the stated authority.
```

### Verify and loop

Execution creates new evidence. Compare what was expected with what actually happened. Feed failures and surprises into the next loop.

The supplied **AI → 4E → LLM** set packages the thinking loop. **AI → 4E → Agentic** adds controlled execution, verification and human accountability.

## Choose the right autonomy

Not every task should become fully agentic.

### Level 1 — AI assists

The AI drafts or explains. You perform every action.

Example: draft a reply, but you review and send it.

### Level 2 — AI recommends

The AI compares options. You decide and act.

Example: compare backup approaches, but you select and configure one.

### Level 3 — AI prepares

The AI prepares an action. You approve before it runs.

Example: prepare file changes or an email, but require your approval.

### Level 4 — AI acts inside boundaries

The AI performs reversible, low-risk work inside defined limits and escalates exceptions.

Example: sort copies of files into a temporary folder while originals remain untouched.

### Level 5 — AI manages substantial work

The AI plans and executes multiple responsibilities under human oversight.

Use this only when permissions, monitoring, escalation and independent verification match the possible consequences.

Use **AI → Agent → Autonomy** to choose deliberately. More autonomy is not automatically better.

## Manage an agent in plain language

Use this sequence:

**Objective → Decompose → Assign → Context → Bound → Approve → Monitor → Escalate → Verify → Learn**

### Objective

State the outcome and how success will be recognized.

### Decompose

Break the outcome into clear responsibilities. Avoid one vague instruction that hides many decisions.

### Assign

Choose whether each responsibility belongs to you, another person, an AI assistant, an agent or ordinary software.

### Context

Provide what is needed for that responsibility. Do not expose unrelated personal or confidential information.

### Bound

Define permitted actions, forbidden actions, accessible data and limits.

### Approve

Keep explicit approval before consequential or irreversible actions.

### Monitor

Watch outcomes and exceptions. You do not need to interrupt every safe, low-risk step.

### Escalate

Require the agent to stop when information conflicts, tools fail, confidence is inadequate, permission is missing or the action exceeds authority.

### Verify

Use evidence separate from the agent’s own statement that it succeeded.

### Learn

Turn useful results, failures and surprises into better instructions, checks and Library Inserts.

The supplied **AI → Agent → Manager** set gives you this whole sequence.

## Define boundaries before tools are used

A useful boundary statement answers:

- What may the agent read?
- What may it create or change?
- What may it delete?
- May it communicate with another person?
- May it spend money or create a commitment?
- Which actions require approval?
- What should happen if the request cannot be completed safely?

Example:

```text
You may inspect the supplied copies and create a proposed folder plan.
Do not rename, move, overwrite, delete, upload, or share files.
Stop if duplicate names make the plan ambiguous.
```

Use **AI → Agent → Boundaries** and **AI → Agent → Escalate** before allowing meaningful action.

## Delegate one responsibility cleanly

When giving work to an agent, include:

```text
Objective:
Responsibility:
Required inputs:
Expected output:
Definition of done:
Allowed actions:
Forbidden actions:
Approval required for:
Stop and escalate when:
Evidence to return:
```

Use **AI → Agent → Delegate** as a reusable checklist.

## Verify outcomes, not confident wording

An agent can complete steps without achieving the intended result. Verification should ask:

- Did the outcome actually occur?
- Did the agent stay inside its authority?
- Were important records, tests or system states checked?
- Were there unintended effects?
- Can evidence independent of the agent confirm success?

Use **AI → Agent → Verify** after action. For important decisions, use **AI → Red Team** before committing.

## Test an agent

Normal software is often tested with exact expected results. Agent responses may differ in wording while still being good—or match wording while behaving badly.

Test representative situations and judge properties:

- used appropriate evidence;
- selected appropriate tools;
- stayed within permission;
- requested approval where required;
- stopped safely when blocked;
- produced a useful outcome;
- avoided prohibited actions.

Include difficult situations:

- missing information;
- contradictory information;
- misleading input;
- unavailable tools;
- denied permission;
- a request outside authority;
- an irreversible action without approval.

Use **AI → Test → Agent Evaluation** and **AI → Test → Adversarial**. Keep important failures as future evaluation cases.

## Practical non-developer examples

### Compare a purchase

1. Explore realistic options.
2. Require current evidence and direct sources.
3. Compare price, ownership cost, reliability and return policy.
4. Ask a Red Team question about the leading choice.
5. Decide yourself.

Do not allow an agent to purchase without a specific approval step.

### Organize a trip

1. Put dates, travelers and constraints in Project Fields.
2. Use AI to explore routes and activities.
3. Verify current schedules and cancellation rules.
4. Let an agent prepare an itinerary.
5. Require approval before reservations or messages.

### Prepare family information

1. Identify what output is needed.
2. Provide only relevant source material.
3. Ask AI to draft and flag missing facts.
4. Verify names, dates and claims yourself.
5. Keep sensitive values outside ordinary prompts where possible.

### Build a personal application without being a professional developer

1. Describe the smallest useful outcome.
2. Test the riskiest unknown before building everything.
3. Give the AI the latest complete source—not remembered fragments.
4. Approve one bounded change at a time.
5. Require build, automated tests and a real user check.
6. Save known-good checkpoints.

NovaInsert’s AI, Agent, Code Review and Test sets support this process without requiring you to memorize every instruction.

## Use NovaInsert with an AI conversation

Recommended setup:

1. Create one NovaInsert Project for the outcome.
2. Link the browser or application containing the AI conversation.
3. Attach only the Library sets relevant to the current phase.
4. Keep Project-specific context in Fields or dedicated Inserts.
5. Use `toCB` when you want to review and paste manually.
6. Use `toNI` when the AI field is not a stable linked destination.
7. Read the AI response as evidence—not automatic truth.

Avoid attaching so many sets that choosing the next Insert becomes harder than writing the request.

## A compact reusable flow

For ordinary AI help:

1. State the outcome.
2. Provide relevant context.
3. Use Explore, Evidence and Evaluate.
4. Decide.
5. Ask for a bounded plan.
6. Verify the result.

For agentic AI:

1. State the outcome.
2. Decompose responsibilities.
3. Set authority and boundaries.
4. Define approval and escalation.
5. Execute only inside those limits.
6. Verify independently.
7. Learn from actual outcomes.

## Final rule

Use AI to reduce effort and expand possibilities. Keep human judgment and accountability wherever consequences matter.
