# NovaInsert User Guide

Use this guide when you want to accomplish a task in NovaInsert. Start with **README — Start Here** if you have not yet sent your first Insert.

## What NovaInsert does for you

NovaInsert holds reusable text, commands and keyboard actions outside the applications where you use them. You choose an exact destination, then send an Insert without repeatedly finding, remembering or retyping it.

The basic flow is:

**Project → destination → Insert**

You can also copy an Insert to the Clipboard or keep it in NovaInsert for pasting at your current cursor.

## Organize work with Projects

A Project keeps related destinations, Inserts, Library sets, Fields and TODO items together.

- Select **+** to create a Project.
- Select a Project icon to manage it.
- Hover over a Project to see its TODO, Linked Windows and attached Library sets.
- Use the temporary arrows to reorder Projects.
- Home behaves like every other Project.
- Use **More → Open Project Folder** after giving `[ProjectRoot]` a value.

Choose a Project name and icon that make sense at a glance. The name appears above and below its icon without covering the center.

## Send to an ordinary Windows application

### Link the exact Window

1. Open the destination application and show the screen you normally use.
2. Open Project management.
3. Select **+ Add Linked Window**.
4. When prompted, select the intended entry point.
5. Name and save the Linked Window.

NovaInsert records the exact Window and a position within it. The position adjusts when the Window size changes. Relink if the application layout changes enough that the saved position is no longer correct.

### Check which Window is linked

Hover continuously over the Linked Window for two seconds. NovaInsert flashes the saved destination briefly.

- Identification does not bring the Window forward.
- Moving away cancels a pending identification.
- Starting an Insert cancels identification.

### Send an Insert

Select the Insert once. NovaInsert closes its menus, brings the exact Window forward, selects the saved entry point and sends the prepared text.

NovaInsert stops instead of using another Window when the saved destination is missing or has changed.

## Create and manage Inserts

From Linked Window management, you can add, edit, reorder, enable, disable or delete Inserts.

An Insert can contain:

- ordinary text;
- multiple lines;
- Project Fields;
- automatic Windows Fields;
- one complete keyboard command.

Use **Quick Insert** for text needed once. In Quick Insert:

- **Enter** sends;
- **Shift+Enter** adds another line.

Use the editor’s **Insert Field** and **Insert Key** controls when you do not want to type token syntax yourself.

### Decide whether Enter is sent

**Add Enter** sends Enter after ordinary text.

- Leave it off when filling a field or composing text.
- Turn it on only when you want the destination to submit or run the text.

The Settings default affects newly created Inserts only. Existing Inserts keep their own choice.

## Reuse Project-specific values with Fields

Put a Field name in brackets:

```text
Hello [Name], your request is ready.
Set-Location -LiteralPath '[ProjectRoot]'
```

NovaInsert discovers these names and shows their values in Project management.

### Required Field

```text
[Name]
```

A missing or blank value stops execution, `toCB` and `toNI`.

### Optional Field

```text
[MiddleName?]
```

A missing or blank optional value becomes empty text.

Field names start with a letter. They may contain letters, numbers, `_`, `.`, `:`, or `-`. Letter case does not create a different Field.

## Insert current Windows information with WIN Fields

WIN Fields are filled automatically and do not appear as editable Project Fields.

| Field | What NovaInsert inserts |
| --- | --- |
| `[WIN:USERNAME]` | Current Windows username |
| `[WIN:COMPUTERNAME]` | Computer name |
| `[WIN:USERPROFILE]` | User profile folder |
| `[WIN:DESKTOP]` | Desktop folder |
| `[WIN:DOCUMENTS]` | Documents folder |
| `[WIN:DOWNLOADS]` | Downloads folder |
| `[WIN:TEMP]` | Temporary folder |
| `[WIN:DATE]` | Local date as `yyyy-MM-dd` |
| `[WIN:TIME]` | Local time as `HH:mm:ss` |
| `[WIN:DATETIME]` | Local date and time |
| `[WIN:OS]` | Windows description |
| `[WIN:OSVERSION]` | Windows version |
| `[WIN:CB]` | Current text in the Windows Clipboard |

Example:

```text
Saved by [WIN:USERNAME] on [WIN:DATE] at [WIN:TIME].
```

`[WIN:CB]` requires text in the Clipboard. Its preview refreshes when the Insert list opens.

## Send a keyboard action with KBD

A KBD Insert sends one key or key combination rather than text:

```text
[KBD:CTRL+C]
[KBD:CTRL+SHIFT+R]
[KBD:ALT+F4]
[KBD:WIN+D]
[KBD:F5]
[KBD:TAB]
```

Use **Insert Key → Custom Key Combination** to create and validate one.

Rules:

- The KBD expression must be the entire Insert.
- Do not combine text and KBD in one Insert.
- Modifiers are `CTRL`, `SHIFT`, `ALT`, and `WIN`.
- The final key can be `A`–`Z`, `0`–`9`, `F1`–`F24`, or a supported named key.
- Named keys include `BACKSPACE`, `TAB`, `ENTER`, `ESC`, `SPACE`, `PAGEUP`, `PAGEDOWN`, `END`, `HOME`, arrows, `INSERT`, `DELETE`, and named punctuation.

For an ordinary Linked Window, KBD activates the Window without selecting the saved click point. This preserves the control or selection already active in that Window.

KBD Inserts do not update `toNI`, because `toNI` holds text. **toCB** copies the literal KBD expression; it does not perform the keys.

## Choose between direct send, toCB and toNI

### Direct send

Use this when the destination is stable and linked. NovaInsert finds it and sends the Insert there.

### toCB

Select **toCB** to resolve Fields and replace the Windows Clipboard with the prepared text. You decide where and when to use ordinary `Ctrl+V`.

In the Library window, row-level **toCB** copies the exact stored line. It cannot resolve Project Fields because no Project is selected there.

### toNI

Select **toNI** to resolve Fields and place the text in NovaInsert’s session-only buffer. Sending ordinary text directly also updates this buffer.

To paste it:

1. Put the cursor in any editable field, linked or unlinked.
2. Press the configured NI hotkey.
3. Keep focus on that field until the paste completes.

NovaInsert temporarily uses the Clipboard, sends normal `Ctrl+V`, then restores the previous Clipboard contents.

`toNI` is intentionally empty after NovaInsert restarts.

## Keep a Project TODO

Project TODO is a plain unnumbered list. Use it as short external memory for the Project.

TODO **toCB** copies a titled, numbered version suitable for sharing. Project Fields are resolved during the copy.

## Attach a reusable Library Insert Set

A Library Insert Set, or LIS, is an ordered group of Inserts. The file does not contain a destination, so the same set can be reused in several Projects.

1. Open Project management.
2. Open **LIS**.
3. Attach the desired set.
4. Choose an ordinary Linked Window or NIT destination.
5. Review **Add Enter** and any NIT choices.
6. Save the Project.

Editing a LIS changes every Project attachment that uses that file. Detaching it does not delete the file and does not close a Terminal tab.

Read **NovaInsert Library Guide** for every supplied set, important uses and safety notes.

## Work with an exact Windows Terminal tab using NIT

NIT routes one attached LIS to one exact Windows Terminal tab.

- **Refresh** checks the configured tab.
- **Open** creates the exact missing tab or focuses the exact existing tab.
- **Focus** selects only the exact existing tab.
- **CD** accepts an absolute folder or a Field such as `[ProjectRoot]`.
- **Add Enter** runs the command after sending it.
- **Return to NI** restores the previous foreground Window after sending.

Possible status includes Missing, Open, Focused, Duplicate and Error. Duplicate exact tab names block sending.

Saving, detaching or exiting NovaInsert never closes Terminal tabs. After restart, saved LIS attachments remain. A missing NIT tab is checked again and is created only through **Open** or a confirmed execution path.

## Protect private values with Hideout

Use Hideout for values that should not live in ordinary Inserts, Fields or the Clipboard.

The title always shows the current state: **Locked**, **Run Mode**, or **Edit Mode**. Entering the password opens Run Mode. Select the pencil and confirm the password only when you need Edit Mode. **Add Group** creates a group; **Add Key** adds a Key/V1/V2 record to the selected group.

- Hideout stores encrypted Key/V1/V2 records.
- You explicitly link its destination for the current session.
- The link must be made again after restart.
- Hideout types characters directly.
- It does not use the Clipboard.
- It never adds Enter automatically.

Confirm the selected field before sending a Hideout value.

## Change Settings

Open **... → Settings**.

### Add Enter to new Inserts

Choose the default for new Inserts. Existing Inserts are unchanged.

### Enable NI Hotkey

Register or unregister the global `toNI` paste hotkey immediately.

### NI Hotkey Choice

Choose one:

- `Ctrl+Alt+N`
- `Ctrl+Alt+Insert`
- `Ctrl+Alt+F9`

The choice applies immediately. If Windows or another application already owns it, NovaInsert reports failure rather than silently choosing something else.

### Test NI Hotkey

Test whether the selected combination is available. Testing does not enable a disabled hotkey.

### Theme

Choose Dark or Light. Main and secondary windows use the selected theme.

### GUI Effects

Sounds and Nova dragon flight are off by default. Turn them on under **GUI Effects** when you want visible and audible feedback.

- **Enable sounds** turns on UI sounds.
- Sound choices are separate for Hover, Click, Insert, Error, Busy and Link.
- Hover sound is intentionally kept away from broad main-panel movement to avoid noise.
- **Enable Nova dragon flight** shows the insert direction from NI to the target point. This is especially useful while learning Linked Windows.

## Manage your Library files

Open **... → Library**.

- Edit, reorder or delete rows.
- Use row-level **toCB** to copy an exact line.
- Select **Open Folder** to reach `%LOCALAPPDATA%\NovaInsert\Library`.
- Select **Scan** after adding or changing files outside NovaInsert.
- Click any Library tree row title to open or close that branch, including lower-level branches.

Name a custom file:

```text
Category - Subcategory - Set Name.lis.json
```

Example:

```text
Personal - Writing - Replies.lis.json
```

Starter files are copied only when that filename is absent. Startup does not overwrite an existing user-edited Library file.

## Add your own guide

1. Open **Guides → Open Folder**.
2. Create a folder such as `My NovaInsert Notes`.
3. Put `Guide.md` inside it.
4. Keep that guide’s images inside its own folder.
5. Reopen the Guides chooser.

User guides live under `%LOCALAPPDATA%\NovaInsert\Guides`. Shipped guides are external files in the application’s `Guides` folder, not inside the DLL.

The shipped guides share images from the application’s `Guides\Images` folder. A user guide remains self-contained so moving or backing it up does not break its images.

If a user guide has the same folder name as a shipped guide, NovaInsert shows the user guide.

## Understand status and recover cleanly

- `…` means work is active.
- `✓` means success.
- `!` means failure.
- Failures briefly flash the status area.
- Hover over status for the complete message.
- Select status to clear it.

When an Insert stops:

1. Read the status.
2. Correct the stated Window, Field, focus, Clipboard, hotkey, duplicate-tab or busy condition.
3. Try once more.

## Use NovaInsert safely

- Test unfamiliar commands in a harmless destination.
- Review resolved Fields before first use.
- Confirm **Add Enter** before sending commands.
- Do not change focus while an action is being sent.
- Use KBD actions only when you understand what they do in the current application.
- Keep sensitive values in Hideout.
- Treat supplied command sets as examples to review, not permission to run unknown commands.
